﻿namespace Cosmetics.Models.Enums
{
    public enum GenderType
    {
        Men,
        Women,
        Unisex
    }
}
