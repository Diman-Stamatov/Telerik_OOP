﻿namespace Cosmetics.Commands.Contracts
{
    public interface ICommand
    {
        string Execute();
    }
}
